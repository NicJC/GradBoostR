#' Predict using a GradBoostR model
#'
#' @param object A gradboostr_model from gradboostr_fit().
#' @param newdata Matrix or data.frame of features.
#' @param type "response" or "prob" (classification only).
#' @param ... Not used.
#'
#' @return Numeric vector (regression), factor (classification), or probability matrix.
#' @export
gradboostr_predict <- function(object, newdata, type = c("response", "prob"), ...) {

  type <- match.arg(type)

  method <- object$method

  if (method == "gbm") {
    return(gbm_predict(newdata,
                       object$model,
                       object$learning_rate,
                       object$init_value))
  }

  if (method == "rf") {
    # regression RF
    return(rf_predict_fast(newdata, object$model))
  }

  if (method == "rf_class") {

    if (type == "response") {
      raw <- rf_predict_fast_class(newdata, object$model)
      return(factor(object$class_labels[raw + 1],
                    levels = object$class_labels))
    }

    if (type == "prob") {
      stop("rf_class probability path temporarily disabled for debugging")
    }
  }


  if (method == "nn") {
    return(nn_predict_model(newdata, object$model))
  }

  stop("Unknown method")
}
